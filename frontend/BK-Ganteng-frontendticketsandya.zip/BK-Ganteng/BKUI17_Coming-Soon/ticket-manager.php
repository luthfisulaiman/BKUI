<?php
include 'head.php';
 ?>
<title>Beli Tiket</title>

 <?php
 include 'foot.php';
  ?>
