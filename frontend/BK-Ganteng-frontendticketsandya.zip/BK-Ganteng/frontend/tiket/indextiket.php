<?php
include "head.php";
?>
<title>Coming Soon BKUI17</title>

<div class="text-container">
  <h1 class="coming-soon">Pemesanan Tiket</h1>
  <h1 class="bkui17">BKUI17</h1>
</div>

<body class="wrapper">
<div class="container content animated bounceInUp">
	<div class="col-md-4">
		<img src ="app/images/coupon (2).png" class = "options">
		<h3 class="text-menu">Aktivasi Voucher</h3>
	</div>
	<div class="col-md-4">
		<img src ="app/images/ticket.png" class = "options">
		<h3 class="text-menu">Beli Tiket</h3>
	</div>
	<div class="col-md-4">
		<img src ="app/images/search.png" class = "options">
		<h3 class="text-menu">Lacak Tiket</h3>
	</div>
</div>
</body>

<!--?php
include "foot.php";
?-->
