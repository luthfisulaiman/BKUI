
<<<<<<< HEAD
</div>

<div class="preloader">
  <div class="sk-spinner sk-spinner-wave">
    <div class="sk-rect1"></div>
    <div class="sk-rect2"></div>
    <div class="sk-rect3"></div>
    <div class="sk-rect4"></div>
    <div class="sk-rect5"></div>
  </div>
</div>
</div>

<script type="text/javascript" src="vendor/js/jquery-1.11.2.min.js"></script>
<script type="text/javascript" src="vendor/js/jquery.tooltipster.min.js"></script>
<script type="text/javascript" src="vendor/js/jquery.countdown.min.js"></script>
<script type="text/javascript" src="vendor/js/remodal.min.js"></script>
=======
</body>
<script type='text/javascript' src='app/bootstrap/js/bootstrap.js'></script>
>>>>>>> cde9d98b1548cd8854fbf02ff756b53fa6382fa9
<script type="text/javascript" src="app/js/app.js?v=1.1.2"></script>
<script type="text/javascript" src="app/js/script.min.js?v=1.0"></script>
</html>
