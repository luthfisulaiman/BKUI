<link rel="stylesheet" type="text/css" href="vendor/css/font-awesome.min.css"/>
  <link rel="stylesheet" type="text/css" href="vendor/css/tooltipster.css"/>
  <link rel="stylesheet" type="text/css" href="vendor/css/tooltipster-shadow.css"/>
  <link rel="stylesheet" type="text/css" href="vendor/css/remodal.css"/>
  <link rel="stylesheet" type="text/css" href="vendor/css/remodal-default-theme.css"/>
  <link rel="stylesheet" type="text/css" href="app/css/styles.css"/>
  <link rel="stylesheet" href="app/css/animate.css"/>
  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Chewy" />
  <title>Tiket BKUI17</title>
</head>
<body>
<!DOCTYPE html>
<html>
<head> 
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <link rel="shortcut icon" href="app/images/favicon.png" type="image/x-icon" />
  <link rel="stylesheet" type="text/css" href="app/bootstrap/css/bootstrap.css"/>
  <link rel="stylesheet" type="text/css" href="app/css/styles.css"/>
  <title>Coming Soon BKUI17</title>
  <script type="text/javascript" src="app/jquery/jquery-3.2.1.min.js"></script>
</head>

