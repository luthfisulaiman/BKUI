<?php
<<<<<<< HEAD
include "head.php";
?>
<title>Coming Soon BKUI17</title>
<div class="text-container">
  <h1 class="coming-soon">Coming Soon</h1>
  <h1 class="bkui17">BKUI17</h1>
  <h2 class="date">11 - 12 November 2017</h2>
  <div class="cd-container">
    <h2 class="hitung-mundur">Hitung Mundur Menuju Pembukaan Penjualan Tiket</h2>
    <h1 id="demo" class="hitung-mundur" ></h1>
  </div>
</div>

<script>
// Set the date we're counting down to
var countDownDate = new Date("June 12, 2017 08:00:00").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();
=======
include 'head.php';?>

<!--Navbar-->
<nav class="navbar-default navbar-head">
		<div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        
      </div>

      <div class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-right menu-top-right" id="nav-right">
        		<li><a href="#"> FAQ</a></li>
            <li><a href="#">Need Help?</a></li>
        	</ul>
      </div>
    </div>
</nav>	  
<!--Section 1-->
<div class='row' id='head-section'>
  <div class='container'>
    <h1 class='text-center'>Pemesanan Tiket BKUI17</h1>
  </div>
</div>

<div class="row" id="content-section">
  <div class="container">
    <div class='col-md-4'>
     
        <img class="img-responsive " width="90px" src="app/images/coupon.png"/>
        <h3 class="text-center">Aktivasi Voucher</h3>
     
    </div>
  <div class='col-md-4'>
     <img class="img-responsive " width="90px" src="app/images/voucher.png"/>
    <h3 class="text-center">Beli Tiket</h3>
    <p></p>
  </div>
  <div class='col-md-4'>
    <img class="img-responsive " width="90px" src="app/images/research.png"/>
    <h3 class="text-center">Lacak Tiket</h3>
  </div>
  </div>
</div>

<div id="footer">
  <p class="text-center">Copyright &copy; 2017. Tim Sistem Informasi BKUI 2017 ;
</div>
<?php include 'foot.php' ?>
>>>>>>> cde9d98b1548cd8854fbf02ff756b53fa6382fa9

  // Find the distance between now an the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("demo").innerHTML = days + " Hari  " + hours + " Jam  "
  + minutes + " menit  " + seconds + " Detik  ";

  // If the count down is finished, write some text
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script>


<?php
include "foot.php";
?>
